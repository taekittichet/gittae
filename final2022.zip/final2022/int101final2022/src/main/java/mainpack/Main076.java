package mainpack;

import utilVarinporn.Tool076;
import valuableVarinporn.Container076;
import valuableVarinporn.Item076;

public class Main076 {
        public static void main(String[] args) {
            testTool();
            System.out.println("------------------");
            testItem();
            System.out.println("------------------");
            testContainer();
        }
        static void testTool(){
            Object[] objects = new Object[0];
            System.out.println(Tool076.isUsable076(""));
            System.out.println(Tool076.isUsable076("Hello"));
            System.out.println(Tool076.isUsable076(objects));
            System.out.println("Count : " + Tool076.count076(objects));
            objects = new Object[5];
            System.out.println(Tool076.isUsable076(objects));
            System.out.println(Tool076.count076(objects));
            objects[1] = "Hello";
            System.out.println(Tool076.count076(objects));
            System.out.println(objects[1]);
            objects[2] = 5;
            objects[3] = true;
            System.out.println(Tool076.isUsable076(objects));
            System.out.println(Tool076.count076(objects));
        }
        static void testItem() {
            System.out.println("Create: " + Item076.create("Fred", 10));
            System.out.println("Create: " + Item076.create("Viktor", 5));
            System.out.println("Create: " + Item076.create("", 5));
            System.out.println(".........");
            System.out.println("Add: " + Item076.create("Megan",5).add(Item076.create("Ted",4)));
            System.out.println(".........");
            System.out.println("Name Matched: " + Item076.create("Jason",1).isMatched(Item076.create("Jason",5)));
            System.out.println("Name Matched: " + Item076.create("Jason",1).isMatched(Item076.create("May",1)));

        }
        static void testContainer(){
            Item076 item1 = new Item076("Jason", 5);
            Item076 item2 = new Item076("Mandy", 3);
            Item076 item3 = new Item076("Ted", 10);
            Item076 item4 = new Item076("Freddy", 2);
            Item076 item5 = new Item076("Chick", 7);
            Item076 item6 = new Item076("Fox", 15);
            Container076 container = new Container076();
            container.add(item1);
            System.out.println(container);
            container.add(item2);
            System.out.println(container);
            container.add(item3);
            container.add(item4);
            container.add(item5);
            System.out.println(container);
            container.remove(item1);
            System.out.println(container);
        }
}

