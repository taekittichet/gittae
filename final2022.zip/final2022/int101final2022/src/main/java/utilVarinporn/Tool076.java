package utilVarinporn;

public class Tool076 {
    public static boolean isUsable076(String s){
        if (s != null && !s.isBlank()) return true;
        return false;
    }

    public static boolean isUsable076(Object[] objects){
        if (objects != null && objects.length > 0) return true;
        return false;
    }

    public static int count076(Object[] objects){
        if (!isUsable076(objects)) return -1;
        return objects.length;
    }
}
