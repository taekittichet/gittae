//StudentID: 66130500076
//StudentName: Varinporn Kiratipattanakorn

package lib076;

public class BookList66076 {
    private final Book66076 book;
    private BookList66076 next;
    private BookList66076 (Book66076 book) { this.book = book; }
    public static BookList66076 newList() { return new BookList66076(null); } public boolean add(Book66076 book) {
        if (book == null) return false;
        var current = this;
        while (current.next != null) {
            current = current.next;
            if (current.book.equals(book)) return false;
    }
        current.next = new BookList66076(book);
        return true;
    }
    @Override
    public String toString() {
        var current = this;
        var sb = new StringBuilder();
        sb.append("BookList{");
        while ((current = current.next) != null) {
            sb.append("\n ").append(current.book);
        }
        return sb.append("}").toString();
    }

    //8.1
    public double totalPrice076(){
        double total = 0.0;
        for (var cursor = this.next; cursor !=null; cursor = cursor.next) {
            total += cursor.book.getPrice076();
        }
        return total;
    }

    //8.2
    public BookList66076 remove076(Book66076 book){
        if (book == null) return null;
        for (var cursor = this; cursor.next != null; cursor = cursor.next) {
            if (cursor.next.book.equals(book)){
                var found = cursor.next;
                cursor.next = found.next;
                found.next = null;
                var head = BookList66076.newList();
                head.next = found;
                return head;
            }
        }
        return null;
    }

    public Book66076 findTitle(String title){
        if (title == null) return null;
        for (var cur = this.next; cur != null; cur = cur.next) {
            if (cur.book.getTitle076().equals(title))
                return cur.book;
        }
        return null;
    }

    public void concat(BookList66076 list){
        if (list == null) return;
        var cur = this;
        while (cur.next != null) cur = cur.next;
        cur.next = list.next;
        list.next = null;
    }
}
