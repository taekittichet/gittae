package valuableVarinporn;

import utilVarinporn.Tool076;

public class Item076 {
    private final String name;
    private int amount;

    public Item076(String name, int amount) {
        this.name = name;
        this.amount = amount;
    }

    public static Item076 create(String name, int amount){
      if (Tool076.isUsable076(name) && amount > 0) {
          return new Item076(name,amount);
      }
      return null;
    }

    @Override
    public String toString() {
        return "(" + name + "," + amount + ")";
    }

    public int add(Item076 item){
        this.amount += item.amount;
        return this.amount;
    }

    public boolean isMatched(Item076 item){
        if (this.name.equals(item.name)) return true;
        return false;
    }
}
