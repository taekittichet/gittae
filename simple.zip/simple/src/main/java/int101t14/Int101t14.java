package int101t14;
import sample.Simple;
import java.util.Arrays;

public class Int101t14 {
    public static void main(String[] args) {
//        demoArrays();
//        demoCopyingArrayContent();
        demoVarargs();
    }

    static void demoVarargs() {
        String s = concatSimple("Start String",
                new Simple(30,"T"),
                new Simple(10,"Ten"),
                new Simple(15,"Five"),
                new Simple(2,"Inside"),
                new Simple(10,"Teen"),
                new Simple(20,"TT"));
        System.out.println("Result = " + s);
    }

    static String concatSimple(String init, Simple...s){
        String result = init;
        for (Simple simple : s){
            result += simple.getText();
        }
        return result;
    }

    static void demoCopyingArrayContent() {
        var s = new Simple[] { new Simple(30,"T"),
                new Simple(10,"Ten"),
                new Simple(15,"Five"),
                new Simple(2,"Inside"),
                new Simple(10,"Teen"),
                new Simple(20,"TT")};
        System.out.println("s.length = " + s.length);
        var c = Arrays.copyOf(s,s.length - 2);
        System.out.println("s = " + Arrays.toString(s));
        System.out.println("c (s-2) = " + Arrays.toString(c));
        c = Arrays.copyOf(s,s.length + 2);
        System.out.println("c (s+2) = " + Arrays.toString(c));

        Simple[] d = new Simple[7];
        System.arraycopy(s,0,d,0,s.length);
    }

    static void demoArrays() {
        // sort = เรียงข้อมูล
        int[] x = {2,9,24,6,2,4,79,24,0,-5,2,9,-5};
        Arrays.sort(x);
        System.out.println("content: " + Arrays.toString(x));
        System.out.println("binarySearch..." + Arrays.binarySearch(x,2));

        var s = new Simple[] {
                new Simple(30,"T"),
                new Simple(10,"Ten"),
                new Simple(15,"Five"),
                new Simple(2,"Inside"),
                new Simple(10,"Teen"),
                new Simple(20,"TT")
        };
        System.out.println("s: " + Arrays.toString(s));
        Arrays.sort(s);
        System.out.println("s: " + Arrays.toString(s));
        Simple search = new Simple(2,"Any");
        int f = Arrays.binarySearch(s,new Simple(2,"Any"));
        System.out.println("Position : " + f);
        System.out.println("s[f] : " + s[f]);
        System.out.println("s[f].equals(search) : " + s[f].equals(search));


    }
}
