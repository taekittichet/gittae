//StudentID: 66130500076
//StudentName: Varinporn Kiratipattanakorn

package lib076;

import util66076.U66076;

public class Book66076 {
    //7.1
    private final long isbn076;
    private final String title076;
    private final double price076;

    //7.2
    public Book66076(String title076, double price076){
        if (title076 == null || title076.isBlank() || price076 <= 0) {
            throw new IllegalArgumentException("Invalid Initialization");
        }
        this.title076 = title076;
        this.price076 = price076;

        long temp = U66076.unique076();
        isbn076 = temp * 10 + U66076.checkDigit076(temp);
    }

    //7.3
    public long getIsbn076() {
        return isbn076;
    }

    public String getTitle076() {
        return title076;
    }

    public double getPrice076() {
        return price076;
    }


    //7.4
   @Override
    public String toString(){
        return String.format("Book(%02d-%05d-%04d-%1d,%s,%.2f)"
                ,isbn076 / 1_00000_0000_0L
                ,isbn076 % 1_00000_0000_0L / 1_0000_0
                ,isbn076 % 1_0000_0 / 1_0
                ,isbn076 % 1_0
                , title076, price076);
   }


    //7.5
    @Override
    public boolean equals(Object obj) {
        return this == obj;
    }

    //7.6
    @Override
    public int hashCode() {
        return (int) isbn076;
    }
}
