package mainpack;

import jdk.jshell.execution.Util;
import obj.varinporn.Obj076;
import util.varinporn.Util076;

public class Main076 {
    public static void main(String[] args) {
        testComputeRightTriangleArea();
        testEvaluate076();
        testComputeMagicVarinporn();
        testCompare();
        testIsGreaterThan();
    }

    private static void testIsGreaterThan() {
        Obj076 o = new Obj076("id001","Johnny",9.2);
        Obj076 b = new Obj076("id002","Betty",22.2);
        System.out.println("4.6 : " + b.isGreaterThan(o));
    }

    private static void testCompare() {
        Obj076 o = new Obj076("id001","Johnny",9.2);
        Obj076 b = new Obj076("id002","Betty",2.2);
        System.out.println("4.5 : " + Obj076.compare(o,b));
    }

    private static void testComputeMagicVarinporn() {
        System.out.println("3.4 : " + Util076.computeMagicVarinporn(1,6,2));
    }

    private static void testEvaluate076() {
        System.out.println("3.3 : " + Util076.evaluate076(98));
    }

    private static void testComputeRightTriangleArea() {
        System.out.println("3.2 : " + Util076.computeRightTriangleArea(20,10));
    }
}
