//StudentID: 66130500076
//StudentName: Varinporn Kiratipattanakorn

package util66076;

public final class U66076 {
    private static long seed076 = 66130500076L;  //6.1
    private U66076() {}  // 6.2

    //6.3
    public static long unique076(){
        long old = seed076;
        seed076 += 1 + (int) (Math.random() * 9);
        return old;
    }

    //6.4
    public static int checkDigit076(long number){
        if (number < 0) return -1;
        int result = 0;
        for (int dir = 1; number > 0; dir = 0 - dir) {
            result += (number % 10) * dir;
            number /= 10;
        }
        if (result < 0) result = 0 - result;
        return result % 10;
    }
}
