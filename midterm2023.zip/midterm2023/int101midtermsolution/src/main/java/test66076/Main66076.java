//StudentID: 66130500076
//StudentName: Varinporn Kiratipattanakorn

package test66076;

import lib076.Book66076;
import lib076.BookList66076;
import util66076.U66076;

import java.awt.print.Book;

public class Main66076 {
    public static void main(String[] args) {
        //testUnique076();
        //testCheckDigit076();
        //testBook076();
        //testBookList076();
        testNewBookList();
    }

    static void testNewBookList() {
        var list1 = BookList66076.newList();
        var list2 = BookList66076.newList();
        list1.add(new Book66076("One", 250.75));
        list1.add(new Book66076("Two",400.50));
        list1.add(new Book66076("Three", 550.25));

        list2.add(new Book66076("Four", 300.50));
        list2.add(new Book66076("Five", 650.75));
        list2.add(new Book66076("Six", 150.25));

        System.out.println("List1 : " + list1);
        System.out.println("List2 : " + list2);
        list1.concat(list2);
        System.out.println("");
        System.out.println("After List1 concat List2");
        System.out.println("List1 : " + list1);
        System.out.println("List2 : " + list2);

        System.out.println("");
        System.out.println("List1 find Four : " + list1.findTitle("Four"));
        System.out.println("List2 find Four : " + list2.findTitle("Four"));





    }

    static void testUnique076() {
        System.out.println("");
        System.out.println("### Test Unique076 ###");
        System.out.println(U66076.unique076());
    }

    static void testCheckDigit076() {
        System.out.println("");
        System.out.println("### Test CheckDigit076 ###");
        System.out.println(U66076.checkDigit076(-4));
        System.out.println(U66076.checkDigit076(926184));
    }

    static void testBook076() {
        System.out.println("");
        System.out.println("### Test Book076 ###");

        Book66076 b0,b1,b2;
        try {
            b0 = new Book66076("Invalid",-20.0);
            System.out.println(b0);
        } catch (Exception e) {
            System.out.println("It's reight. It's an error");
        }
        b1 = new Book66076("One", 100);
        b2 = new Book66076("two",20.25);
        System.out.println("Book one : " + b1);
        System.out.println("Book two : " + b2);
        System.out.println("b1.getIsbn076() : " + b1.getIsbn076());
        System.out.println("b1.getTitle076() : " + b1.getTitle076());
        System.out.println("b1.getPrice076() : " + b1.getPrice076());
        System.out.println("Book One hashcode : " + b1.hashCode());
        System.out.println("equal : b1.equal(b2) ? " + b1.equals(b2));
        b0 = b1;
        System.out.println("equal : b1.equal(b0) ? " + b1.equals(b0));
    }

    static void testBookList076() {
        System.out.println("");
        System.out.println("### Test BookList ###");
        BookList66076 books = BookList66076.newList(); //newList
        System.out.println("Books: " + books); //toString
        System.out.println("Total price : " + books.totalPrice076());

        //book1
        Book66076 b1 = new Book66076("First",10.25);
        System.out.println("Add book [" + b1 + "] ? " + books.add(b1)); //addBook
        System.out.println("Books: " + books); //toString
        System.out.println("Total price : " + books.totalPrice076());
        System.out.println("");

        //book2
        Book66076 b2 = new Book66076("Second",300.75);
        System.out.println("Add book [" + b2 + "] ? " + books.add(b2)); //addBook
        System.out.println("Books: " + books); //toString
        System.out.println("Total price : " + books.totalPrice076());
        System.out.println("");

        //book3
        Book66076 b3 = new Book66076("Third",400.25);
        System.out.println("Add book [" + b3 + "] ? " + books.add(b3)); //addBook
        System.out.println("Books: " + books); //toString
        System.out.println("Total price : " + books.totalPrice076());
        System.out.println("");

        System.out.println("Remove null : " + books.remove076(null));
        System.out.println("Remove b1 : " + books.remove076(b1));
        System.out.println("Books: " + books); //toString
        System.out.println("Remove b1 : " + books.remove076(b1));
        System.out.println("Remove b3 : " + books.remove076(b3));
        System.out.println("Books: " + books); //toString
    }
}
