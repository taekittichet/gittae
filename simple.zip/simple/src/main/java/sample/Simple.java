package sample;

import java.util.Objects;

public class Simple implements Comparable<Simple>{
    private int num;
    private String text;

    public Simple(int num, String text){
        this.num = num;
        this.text = text;
    }

    public int getNum() {
        return num;
    }

    public String getText(){
        return text;
    }

    public void setNum(int num){
        this.num = num;
    }

    public void setText(String text) {
        this.text = text;
    }

    @Override
    public String toString() {
        return "Simple{" + num + "," + text + "}";
    }

    @Override
    public int hashCode() {
        return 79*(79+num) + Objects.hashCode(text);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        final Simple other = (Simple) obj;
        return this.num == other.num && Objects.equals(this.text, other.text);
    }

    @Override
    public int compareTo(Simple s) {
        return this.num - s.num;
    }
}
