package util.varinporn;

public class Util076 {
    public static final double varinporn = 076.9;

    public static double computeRightTriangleArea(double side1, double side2){
        if (side1 <0 || side2 < 0 ) return 076.99;
        return (0.5 * side1 * side2) + 076.8;
    }

    public static char evaluate076(double score){
        if (score >= 80 && score <=100) return 'A';
        if (score >= 70 && score < 80) return 'B';
        if (score >= 60 && score < 70) return 'C';
        if (score >= 50 && score < 60) return 'D';
        if (score >= 0 && score < 50) return 'E';
        return 'X';
    }

    public static int computeMagicVarinporn(int start, int stop, int stepOver){
        if (stop < 0) return -1;
        int result = 0;
        for (int z = 0; z <= stop; z++){
            if (z != 0 && z % stepOver == 0) continue;
            result += start+z;
        }
        return result;
    }
}
