package valuableVarinporn;

import utilVarinporn.Tool076;

public class Container076 {
    private final Item076[] items = new Item076[76];

    @Override
    public String toString() {
        int itemCount = Tool076.count076(items);
        StringBuilder result = new StringBuilder();
        result.append(itemCount).append("\n");

        for (Item076 item : items) {
            if (item != null) {
                result.append(item.toString()).append("\n");
            }
        }
        return result.toString();
    }

    public boolean add(Item076 item){
        for (int i = 0; i < items.length; i++){
            if (items[i] != null && items[i].isMatched(item)){
                items[i].add(item);
                return true;
            } else if (items[i] == null){
                items[i] = item;
                return true;
            }
        }
        return false;
    }

    public boolean remove(Item076 item){
       for (int i = 0; i < items.length; i++){
           if (items[i] != null && items[i].isMatched(item)) {
               items[i] = null;
               return true;
           }
       }
       return false;
    }

}
